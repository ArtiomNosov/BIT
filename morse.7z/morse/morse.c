// gcc morse.c ../lesson11/list.c ../lesson11/number.c ../lesson11/list_up.c -o morse.exe
#include "morse_translate.c"
#define short_signal 300
#define long_signal short_signal * 3
#define signal_voice 1000
#define time_wait_for_button 31
#define morse_size 36
void scanf_english(list* cont)
{
        printf("Start to scanf_english\n");
        if (cont == NULL)
                return;
        int state = -1;
        char* english_letter = NULL;
        int ind = -1;
        char buf[2]={0};
        string_t* string_buf = NULL;
        printf("Press esc button to stop scanf\n");
        do {
                state = getch();
                if (state == 27)
                        break;
                buf[0] = state;
                printf("%c", state);
                string_buf = create_string(buf);
                // printf("%s", buf);
                ind = find_ind(english_alphabet, a_size, string_buf);
                delete_string(string_buf);
                insert_number_in_list(cont, ind);
        } while(1);
        printf("\nEnd to scanf_english\n");
}
void scanf_morse(list* cont)
{
        printf("Start to scanf_morse\n");
        if (cont == NULL)
                return;
        int state = -1;
        char* morse_letter = NULL;
        int ind = -1;
        string_t* buf = NULL;
        while(state != 27) {
                printf("Write morse letter:\n");
                morse_letter = get_str();
                // printf("|%s|", morse_letter);
                buf = create_string(morse_letter);
                free(morse_letter);
                buf->string[buf->len-1] = 0;
                ind = find_ind(morse_alphabet, a_size, buf);
                delete_string(buf);
                insert_number_in_list(cont, ind);
                printf("Press esc button to stop scanf\n");
                state = getch();
        }
        printf("\nEnd to scanf_morse\n");
}
void print_menu()
{
        printf("***Menu***\n");
        printf("1) quit\n");
        printf("2) scanf english in english_list\n");
        printf("3) scanf morse in morse_list\n");
        printf("4) printf english_list\n");
        printf("5) printf morse_list\n");
        printf("6) printf english_list in morse\n");
        printf("7) printf morse_list in english\n");
        printf("8) sound english_list\n");
        printf("9) sound morse_list\n");
}
void my_beep(number_t* number)
{
        const char* symbol = NULL;
        if (number == NULL)
                return;
        if (number->number == -1)
                symbol = morse_alphabet[a_size];
        else
                symbol = morse_alphabet[number->number];
        for (size_t i = 0; symbol[i]; i++)
        {
                if      (symbol[i] == '.')
                        Beep(signal_voice, short_signal);
                else if (symbol[i]== '_')
                        Beep(signal_voice, long_signal);
                Sleep(time_wait_for_button);
        }
}
void sound(list* list_numbers)
{
        if (list_numbers == NULL || list_numbers->n < 1)
                return;
        proces_list(list_numbers, (f_t)my_beep);
}
int main()
{
        int state = '0';
        list* english_list = calloc_list();
        list* morse_list = calloc_list();
        while(state != '1') {
                print_menu();
                state = getch();
                if        (state == '2') {
                        delete_list(english_list, free);
                        english_list = calloc_list();
                        scanf_english(english_list);
                } else if (state == '3') {
                        delete_list(morse_list, free);
                        morse_list = calloc_list();
                        scanf_morse(morse_list);
                } else if (state == '4') {
                        printf("english_list:\n");
                        // print_list(english_list);
                        print_numbers_list_in_english(english_list);
                        printf("\n");
                } else if (state == '5') {
                        printf("morse_list:\n");
                        print_numbers_list_in_morse(morse_list);
                        printf("\n");
                } else if (state == '6') {
                        printf("english_list in morse:\n");
                        print_numbers_list_in_morse(english_list);
                        printf("\n");
                } else if (state == '7') {
                        printf("morse_list in english:\n");
                        print_numbers_list_in_english(morse_list);
                        printf("\n");
                } else if (state == '8') {
                        printf("sound english_list:\n");
                        print_numbers_list_in_morse(english_list);
                        sound(english_list);
                } else if (state == '9') {
                        printf("sound morse_list:\n");
                        print_numbers_list_in_morse(morse_list);
                        sound(morse_list);
                } else if (state == '1') {
                        printf("exit\n");
                } else {
                        printf("Wrong\n");
                }
        }
}
