#include "morse_translate.h"
const char* english_alphabet[] = {
        "e", "t", "i", "a",        \
        "n", "m", "s", "u",      \
        "o", "r", "d", "g",      \
        "k", "w", "f", "h",    \
        "j", "l", "p", "q",    \
        "v", "x", "y", "z",    \
        "b", "c", "1", "2",  \
        "3", "4", "5", "6",  \
        "7", "8", "9", "0", " ", "NaN"   \
};
const char* morse_alphabet[] = {
        ".   ",  \
        "_   ",  \
        ". .   ",        \
        ". _   ",        \
        "_ .   ",        \
        "_ _   ",        \
        ". . .   ",      \
        ". . _   ",      \
        "_ _ _   ",      \
        ". _ .   ",      \
        "_ . .   ",      \
        "_ _ .   ",      \
        "_ . _   ",      \
        ". _ _   ",      \
        ". . _ .   ",    \
        ". . . .   ",    \
        ". _ _ _   ",    \
        ". _ . .   ",    \
        ". _ _ .   ",    \
        "_ _ . _   ",    \
        ". . . _   ",    \
        "_ . . _   ",    \
        "_ . . _   ",    \
        "_ _ . .   ",    \
        "_ . . .   ",  \
        "_ . _ .   ",  \
        ". _ _ _ _   ",  \
        ". . _ _ _   ",  \
        ". . . _ _   ",  \
        ". . . . _   ",  \
        ". . . . .   ",  \
        "_ . . . .   ",  \
        "_ _ . . .   ",  \
        "_ _ _ . .   ",  \
        "_ _ _ _ .   ",  \
        "_ _ _ _ _   ", "    ", "NaN"   \
};
void insert_string_in_list(list* cont, const char* arr)
{
        string_t* string = create_string(arr);
        insert_list(cont, string, (copy_t)copy_string);
        delete_string(string);
}
void insert_number_in_list(list* cont, int n)
{
        if (cont == NULL)
                return;
        number_t* number = create_number(n);
        insert_list(cont, number, (copy_t)copy_number);
        free(number);
}
int find_ind(const char** alphabet, size_t size, string_t* string)
{
        
        for (size_t i = 0; i < size; i++)
                if (strcmp(string->string, alphabet[i]) == 0)
                        return i;
        return -1;
}
list* morse_to_numbers(list* morse_list) 
{
        if (morse_list == NULL || morse_list->n < 1)
                return NULL;
        list* res = calloc_list();
        node* curr = morse_list->head;
        size_t ind = 0;
        while (curr)
        {
                ind = find_ind(morse_alphabet, a_size, curr->data);
                insert_number_in_list(res, ind);
                curr = curr->next;
        }
        return res;
}
list* english_to_numbers(list* english_list) 
{
        if (english_list == NULL || english_list->n < 1)
                return NULL;
        list* res = calloc_list();
        node* curr = english_list->head;
        size_t ind = 0;
        while (curr)
        {
                ind = find_ind(english_alphabet, a_size, curr->data);
                insert_number_in_list(res, ind);
                curr = curr->next;
        }
        return res;
}
void print_numbers_in_morse(number_t* number)
{
        if (number == NULL || number->number >= a_size)
                return;
        printf("%s", morse_alphabet[number->number]);
}
void print_numbers_in_english(number_t* number)
{
        if (number == NULL || number->number >= a_size)
                return;
        printf("%s", english_alphabet[number->number]);
}
void print_numbers_list_in_morse(list* cont)
{
        if (cont == NULL || cont->n < 1)
                return;
        f_t f = (f_t)print_numbers_in_morse;
        proces_list(cont, f);
}
void print_numbers_list_in_english(list* cont)
{
        if (cont == NULL || cont->n < 1)
                return;
        f_t f = (f_t)print_numbers_in_english;
        proces_list(cont, f);
}