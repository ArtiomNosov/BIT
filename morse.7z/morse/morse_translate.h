#ifndef MORSE_TRANSLATE_H 
#define MORSE_TRANSLATE_H
#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <windows.h>
#include <string.h>
#include "string.h"
#include "list.h"
#include "number.h"
#define a_size 37
void insert_string_in_list(list* cont, const char* arr);
void insert_number_in_list(list* cont, int n);
int find_ind(const char** alphabet, size_t size, string_t* string);
list* morse_to_numbers(list* morse_list);
list* english_to_numbers(list* english_list);
void print_numbers_in_morse(number_t* number);
void print_numbers_in_english(number_t* number);
void print_numbers_list_in_morse(list* cont);
void print_numbers_list_in_english(list* cont);
#endif
// int main()
// {
//         list* artiom = calloc_list();
//         printf("artiom: \n");
//         insert_string_in_list(artiom, "a");
//         insert_string_in_list(artiom, "r");
//         insert_string_in_list(artiom, "t");
//         insert_string_in_list(artiom, "i");
//         insert_string_in_list(artiom, "o");
//         insert_string_in_list(artiom, "m");
//         insert_string_in_list(artiom, " ");
//         insert_string_in_list(artiom, "n");
//         print_list(artiom);
//         list* artiom_in_numbers = english_to_numbers(artiom);
//         printf("\nartiom_in_numbers = \n");
//         print_list(artiom_in_numbers);
//         printf("\nartiom_in_english = \n");
//         proces_list(artiom_in_numbers, (f_t)print_numbers_in_english);
//         printf("\nartiom_in_morse = \n");
//         proces_list(artiom_in_numbers, (f_t)print_numbers_in_morse);

//         delete_list(artiom, (del_t)delete_string);
//         delete_list(artiom_in_numbers, free);
        
//         artiom = calloc_list();
//         printf("\nartiom: \n");
//         insert_string_in_list(artiom, ". _   ");
//         insert_string_in_list(artiom, ". _ .   ");
//         insert_string_in_list(artiom, "_   ");
//         insert_string_in_list(artiom, ". .  ");
//         insert_string_in_list(artiom, "_ _ _   ");
//         insert_string_in_list(artiom, "_ _   ");
//         print_list(artiom);
//         artiom_in_numbers = morse_to_numbers(artiom);
//         printf("\nartiom_in_numbers = \n");
//         print_list(artiom_in_numbers);
//         printf("\nartiom_in_english = \n");
//         proces_list(artiom_in_numbers, (f_t)print_numbers_in_english);
//         printf("\nartiom_in_morse = \n");
//         proces_list(artiom_in_numbers, (f_t)print_numbers_in_morse);
//         delete_list(artiom, (del_t)delete_string);
//         delete_list(artiom_in_numbers, free);
// }